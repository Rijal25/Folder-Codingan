# print("Berapa nilai penjumlahan dari bilangan berikut, jika x = 250, y = 250, z = 250!!")
# x = eval(input("x = "))
# y = eval(input("y = "))
# z = eval(input("z = "))
# print("Hasil dari penjumlahan x,y,z adalah", (x + y + z))

# print("Berapa nilai pengurangan dari bilangan berikut, jika x = 255, y = 140, z = 30!!")
# x = eval(input("x = "))
# y = eval(input("y = "))
# z = eval(input("z = "))
# print("Hasil dari pengurangan x,y,z adalah", (x - y - z))

# print("Berapa nilai perkalian dari bilangan berikut, jika x = 2, y = 4, z = 5!!")
# x = eval(input("x = "))
# y = eval(input("y = "))
# z = eval(input("z = "))
# print("Hasil dari perkalian x,y,z adalah", (x * y * z))

# print("Berapa nilai pembagian dari bilangan berikut, jika x = 81, y = 9, z = 3!!")
# x = eval(input("x = "))
# y = eval(input("y = "))
# z = eval(input("z = "))
# print("Hasil dari pembagian x,y,z adalah", (x / y / z))

# nama = input("Masukkan nama Anda : ")
# kelas = input("Input nama Kelas : ")
# jurusan = input("Input Jurusan : ")
# print ("Nama    :",nama)
# print ("Kelas   :",kelas)
# print ("Jurusan :",jurusan)



# for genap in range(1,11,1):
#     if genap % 2 == 0: print (genap)








