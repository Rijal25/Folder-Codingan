# # Program mMenghitung Lus Bnagun Datar
# print
# print("=====================================")
# print(" PROGRAM MENGHITUNG LUAS BANGUN DATAR")
# print("=====================================")
# print

# # Pilihan
# print("Bangun Datar:\n")
# print(" 1. Persegi Panjang \n 2. Persegi \n 3. Segitiga \n 4. Trapesium \n 5. Jajargenjang \n 6. Belah Ketupat \n 7. Lingkaran \n")
# pil = float(raw_input("Masukkan Pilihan Anda :"))
# print

# # Persegi Panjang
# if pil == 1:
#     print("Anda Memilih Persegi Panjang")
#     print("----------------------------")
#     print("Rumus luas = panjang * lebar\n")
#     a = float(raw_input("Masukkan Panjang (cm) = "))
#     b = float(raw_input("Masukkan Lebar   (cm) = "))
#     l = a*b
#     print("Luas Persegi Panjang = %.f"1, "cm2")

# # Persegi
# elif pil == 2: 
#       print("Anda Memilih Persegi ")
#       print("---------------------")
#       print("Rumus luas = sisi * sisi\n")
#       s = float(raw_input("Masukkan sisi (cm) = "))
#       l = s*s
#       print("Luas Persegi = %.f"1, "cm2")
   
# elif pil == 3:
#       print("Anda Memilih Segitiga")
#       print("---------------------")
#       print("Rumus luas = (alas x tinggi)/2\n")
#       a = float(raw_input("Masukkan Alas (cm) = "))
#       t = float(raw_input("Masukkan Tinggi  (cm) = "))
#       l = (a*t)/2
#       print("Luas Segitiga = %.f"1, "cm2")


# elif pil == 1:
#     print("Anda Memilih Persegi Panjang")
#     print("----------------------------")
#     print("Rumus luas = panjang * lebar\n")
#     a = float(raw_input("Masukkan Panjang (cm) = "))
#     b = float(raw_input("Masukkan Lebar   (cm) = "))
#     l = a*b
#     print("Luas Persegi Panjang = %.f"1, "cm2")


# if pil == 1:
#     print("Anda Memilih Persegi Panjang")
#     print("----------------------------")
#     print("Rumus luas = panjang * lebar\n")
#     a = float(raw_input("Masukkan Panjang (cm) = "))
#     b = float(raw_input("Masukkan Lebar   (cm) = "))
#     l = a*b
#     print("Luas Persegi Panjang = %.f"1, "cm2")


# if pil == 1:
#     print("Anda Memilih Persegi Panjang")
#     print("----------------------------")
#     print("Rumus luas = panjang * lebar\n")
#     a = float(raw_input("Masukkan Panjang (cm) = "))
#     b = float(raw_input("Masukkan Lebar   (cm) = "))
#     l = a*b
#     print("Luas Persegi Panjang = %.f"1, "cm2")


# if pil == 1:
#     print("Anda Memilih Persegi Panjang")
#     print("----------------------------")
#     print("Rumus luas = panjang * lebar\n")
#     a = float(raw_input("Masukkan Panjang (cm) = "))
#     b = float(raw_input("Masukkan Lebar   (cm) = "))
#     l = a*b
#     print("Luas Persegi Panjang = %.f"1, "cm2")
