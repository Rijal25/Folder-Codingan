# print("Toko Saya")
# print("Pilih Menu :")
# print("1. Es Degan -> Rp.10.000")
# print("2. Nasi Bebek Goreng -> Rp.20.000")
# print("Beli 2 Dapat Diskon 20%")
# opsi = input("Pilih Menunya :")
# if opsi == "1":
#       jumlah = int(input("Jumlah :"))
#       uang_kamu = int(input("Uang Kamu :"))
#       harga = 10000
#       diskon = 20/100
#       if jumlah == 1:
#             print("Kamu Akan Membeli Es Degan berjumlah :",jumlah, "dengan harga : ",harga)
#       elif jumlah == 2:
#             print("Kamu Membeli Es Degan berjumlah :",jumlah, "dengan harga :",harga, "Dan mendapatkan diskon sebesar 20%")
#             print("Total Diskon :",harga*jumlah*20/100)

