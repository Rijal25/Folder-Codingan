# Cara menulis file di python
# menggunakan "w"
print("=================================")
print()
print("Selamat Datang di Program Biodata")
print()
print("=================================")

# Ambil input dari user
nama = input("Nama :")
umur = input("Umur :")
alamat = input("Alamat :")

# format teks
teks = "Nama : {}\nUmur : {}\nAlamat : {}".format(nama, umur, alamat)

# buka file untuk ditulis
biodata = open("biodata.txt", "w")

# tulis teks ke file
biodata.write(teks)

# tutup file
biodata.close()


# Menyisipkan data ke file, menggunakan "a"

print("=================================")
print()
print("Selamat Datang di Program Biodata")
print()
print("=================================")

# Ambil input dari user
nama = input("Nama :")
umur = input("Umur :")
alamat = input("Alamat :")

# format teks
teks = "Nama : {}\nUmur : {}\nAlamat : {}\n---".format(nama, umur, alamat)

# buka file untuk ditulis
biodata = open("biodata.txt", "a")

# tulis teks ke file
biodata.write(teks)

# tutup file
biodata.close()


# Menggunakan "r+"
# awalan
baca = open("nama_file.txt", "r")
# tulis = open("nama_file.txt", "w")

# Program
print("=================================")
print()
print("Selamat Datang di Program Biodata")
print()
print("=================================")

# buka file untuk dibaca dan ditulis
biodata = open("biodata.txt", "r+")

teks = biodata.read()

# cetak isi file
print(teks)

# Ambil input dari user
nama = input("Nama :")
umur = input("Umur :")
alamat = input("Alamat :")

# format teks
teks = "\nNama : {}\nUmur : {}\nAlamat : {}\n---".format(nama, umur, alamat)

# tulis teks ke file
biodata.write(teks)

# tutup file
biodata.close()