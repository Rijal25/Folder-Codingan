# angka = ['4','6','8']

# for urutan_angka in angka:
#     print(urutan_angka)


a = int(input('Masukkan bilangan ganjil lebih dari 25: '))

while a % 2 != 1 or a <= 25:
    a = int(input('Salah, masukkan lagi: '))

print('Benar')



