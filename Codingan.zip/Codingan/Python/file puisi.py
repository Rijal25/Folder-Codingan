# # Membaca text file

# # buka file
# puisi = open("puisi.txt","r")

# # baca isi file
# print (puisi.read())

# # tutup file
# puisi.close()
# # ===============================


# # Membaca text files menggunakan method readlines

# # buka file
# teks_puisi = open("puisi.txt", "r")

# # baca isi file
# puisi = teks_puisi.readlines()

# # cetak baris pertama
# print(puisi[0])
# # cetak baris kedua
# print(puisi[1])

# # tutup file
# teks_puisi.close()


# f = open("puisi.txt", "r")

# print(f.read())

# print (f.read())
 
# print (f.readlines())


# # Menggunakan perulangan for
# teks_puisi = open("puisi.txt", "r")

# puisi = teks_puisi.readlines()

# # cetak isi file dengan perulangan
# for teks in puisi:
#     print(teks)

# teks_puisi.close()


# file_puisi = open("puisi.txt", "r")

# puisi = file_puisi.read()

# print(puisi)

# file_puisi.close()



