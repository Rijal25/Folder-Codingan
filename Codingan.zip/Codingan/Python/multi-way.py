# print("--------------------------------------------")
# print("-- GRADE NILAI MAHASANTRI PETIK 2 JOMBANG --")
# print("--------------------------------------------")

# namaSaya = input("Nama Lengkap: ")
# nilaiSaya = float(input("Nilai Kamu: "))

# print("Nama: ",namaSaya)

# if nilaiSaya < 30.0 :
#     print("Grade : D")
# elif nilaiSaya < 60.0 :
#     print("Grade : C")
# elif nilaiSaya < 80.0 :
#     print("Grade : B")
# else :
#     print("Grade : A")



# print("--------------------------------------------")
# print("-- GRADE NILAI MAHASANTRI PETIK 2 JOMBANG --")
# print("--------------------------------------------")

# while (True):
#     namaSaya = input("Nama Lengkap: ")
#     nilaiSaya = float(input("Nilai Kamu: "))
#     gradeSaya = ""

#     if nilaiSaya < 30.0 :
#         gradeSaya = "D"
#     elif nilaiSaya < 60.0 :
#         gradeSaya = "C"
#     elif nilaiSaya < 80.0 :
#         gradeSaya = "B"
#     else :
#         gradeSaya = "A"

#     print()
#     print("Nama : ",namaSaya)
#     print("Nilai : ",nilaiSaya)
#     print("Grade : ",gradeSaya)
#     print()

#     status = input("Apakah masih ada yang ingin di input? (y = ya, n = tidak)?")
#     print()
#     if status == "n":
#         break



# print("--------------------------------------------")
# print("-- GRADE NILAI MAHASANTRI PETIK 2 JOMBANG --")
# print("--------------------------------------------")

# while (True):
#     namaSaya = input("Nama Lengkap: ")
#     nilaiSaya = float(input("Nilai Kamu: "))
#     gradeSaya = ""

#     if nilaiSaya < 30.0 :
#         gradeSaya = "D"
#     elif nilaiSaya < 60.0 :
#         gradeSaya = "C"
#     elif nilaiSaya < 80.0 :
#         gradeSaya = "B"
#     else :
#         gradeSaya = "A"

#     print()
#     print("Nama : ",namaSaya)
#     print("Nilai : ",nilaiSaya)
#     print("Grade : ",gradeSaya)
#     print()

#     status = input("Apakah masih ada yang ingin di input? (y = ya, n = tidak)? \n")
#     print()
#     if status == "n":
#         print("Program berhenti")
#         break
#     elif status == "y":
#         print("Silahkan input data lagi \n")
#     else :
#         print("Input data tidak dikenali")
#         break
