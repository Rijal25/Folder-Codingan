# import getpass

# print('Program Login Sederhana')
# print('-----------------------')

# username_1 = input('Buat username baru anda : ')
# password_1 = input('Buat password baru anda : ')
# print('\n-----------DATA DIKONFIRMASI-----------')

# username_2 = input('\nMasukkan username anda : ')
# password_2 = getpass.getpass('Masukkan kata sandi : ')

# if username_2==username_1 and passsword_2==password_1:
#     print('----------------------------------------------')
#     print('Login diterima, selamat datang ' + username_1 + '..')
#     print('----------------------------------------------')
# else:
#     print('----------------------------------------------')
#     print('Login ditolak, silahkan coba lagi! ')
#     print('----------------------------------------------')
    