# # Menggunakan writelines
# buah = "ini adalah nama-nama Buah yang mengandung Vitamin C \n"
# buah_list = ["~ Nanas \n", "~ Mangga \n ", "~ Kiwi \n", "~ Jeruk \n", "~ Jambu Biji \n"]

# f = open("buah.txt", "w")
# f.write(buah)
# f.writelines(buah_list)

