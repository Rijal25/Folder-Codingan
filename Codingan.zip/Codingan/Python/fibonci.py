# def fibonacci(n):
#     if n == 0 or n == 1:
#         return n
#     else:
#         return (fibonacci(n-1) + fibonacci(n-2))

# x = int(input("Masukan Batas Deret Bilangan Fibonacci : "))
# for i in range(x):
#     print(fibonacci(i),end=' ')


# n = int(input('Masukkan nilai n: '))
# faktorial = 1

# for i in range(1, n + 1):
#   faktorial *= i

# print(f'{n}! = {faktorial}')


# a = [5, 10, 15, 20, 25, -30, -35]

# print(a)
# print("Nilai terbesar : ", max(a))
# print("Nilai terkecil : ", min(a))