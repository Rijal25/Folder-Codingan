# # Keterangan kelulusan Mahasantri
# print("Keterangan Kelulusan Mahasantri PeTIK 2 Jombang")

# # membuat variabel namaSaya
# namaSaya = input("Masukkan nama lengkap: ")
 
#  # membuat variabel jumlahSetoran
# jumlahSetoran = int(input("Masukkan jumlah setoran: "))

#  # membuat jumlah setoran kurang dari 2
# if jumlahSetoran < 2 :
#      print("Nama: ",namaSaya)
#      print("Hafalan: ",jumlahSetoran)
#      print("Tidak Lulus")

# # selain itu maka,
# else :
#     print("Nama: ",namaSaya)
#     print("Hafalan: ",jumlahSetoran)
#     print("Lulus")


