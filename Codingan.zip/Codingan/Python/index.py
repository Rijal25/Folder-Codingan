# Menerima inputan
angka1 = int(input("Masukkan angka pertama : "))
angka2 = int(5)

# Proses Penjumlahan
hasil = angka1 + angka2

# Proses Output
print(hasil)
print("hasil")
print(int("4") + hasil)


















