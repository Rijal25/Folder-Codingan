# angka1 = 9

# if angka1 > 5 :
#     print("Benar")

# One-way if Statement
# angka1 = int(input("Masukkan bilangan: "))

# # jika angka1 lebih dari 5 maka akan "True"
# if angka1 > 5 :
#     # jika true maka akan mencetak "Benar"
#     print("Benar")

# Two-way if Statement

# Membuat variabel sepeda saya
# sepedaSaya = 5

# Jika sepeda saya kurang lebih sama dengan 2
# if sepedaSaya <= 2:
#     # print cukup
#    print("sepeda saya cukup", sepedaSaya)
#    # selain itu
# else :
#     # print lebih
#     print("sepeda saya lebih", sepedaSaya)

# Cara Menggunakan fungsi
# def salam(nama):
#     print("Hello.....")
#     print("Selamat Datang.....",nama)
#     print("Apa Kabar?",nama)
#     print()

# salam("Rijal")
# salam("Haziq")
# salam("Faiz")



# def luas_persegi_panjang(panjang, lebar):
#     print("Menghitung Luas Persegi Panjang")
#     rumus = panjang * lebar
#     return rumus

# print(luas_persegi_panjang(8, 6))

# def func1():
#     x = 100
#     y = x * 5
#     print('x =', x, '---y =', y)

# def func2():
#     x = 1000
#     y = x / 2
#     print('x =', x, '---y =', y)

# func1()
# func2()


# def tambah(a, b, c):
#     hasil = a + b + c
#     return hasil

# x = tambah(5, 7, 9)
# print(x)


# def solve(a, b):
#     hasil1 = a + b
#     hasil2 = a - b
#     return hasil1, hasil2

# x, y = solve(10, 7)
# print(x)
# print(y)


# def max(a, b, c):
#     if a >= b and a >= c:
#         return a
#     elif b >= a and b >= c:
#         return b
#     else:
#         return c

# terbesar = max(5, -3, 8)
# print("Bilangan terbesar =", terbesar)

#angka1, angka2 = parameter biasa
#angka3 = parameterdefault
# def tes(angka1, angka2, angka3 = 8):
#     print(angka1)
#     print(angka2)
#     print(angka3)

# tes(9, 2)


# def parameter_keyword(teks1, teks2, teks3):
#     print(teks1)
#     print(teks2)
#     print(teks3)

# # parameter biasa
# parameter_keyword("fulan", "selamat", "datang")
# print()
# parameter_keyword(teks3 = "fulan", teks1 = "selamat", teks2 = "datang")

