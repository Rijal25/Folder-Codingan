

# print("=========================================")
# print("+++++ SELAMAT DATANG DI ATM MANDIRI +++++")
# print("=========================================")


# while True :
#       print("+----------------------+")
#       print("Pilih Option :")
#       print("1. Check Saldo Saya")
#       print("2. Ambil Saldo Saya")
#       print("3. Tabung Saldo Saya")
#       print("+----------------------+")
#       option=int(input("Silahkan Pilih Option :"))
      

#       saldo = 500000
#       if option==1:
#             print("saldo anda sekarang adalah :",saldo)


#       elif option==2:
#             nominal = int(input("Masukan Nominal Penarikan : "))
#             sisaSaldo = saldo - nominal
#             print("Sisa Saldo anda sekarang : ",sisaSaldo)


#       elif option==3:
#             print("saldo anda sekarang adalah Rp.",sisaSaldo) 
#             option3=int(input("Masukkan Jumlah Uang : Rp."))
#             saldo = sisaSaldo + option3
#             print("Jumlah Saldo Kamu Sekarang Adalah Rp.",saldo) 
      

#       else:
#             print("xxxxx--->Keyword Anda Salah, Mohon Coba Lagi!<---xxxxx") 
#       lanjutatm = input("Apakah sudah selesai transaksi?(y/n)")
#       if lanjutatm == ('y') :
#             print()
#       else :
#             break

# print()
# print("=======================")
# print("+++++ TERIMAKASIH +++++")
# print("=======================")





























# Kata-kata hari ini

# print("*************************************************")
# print("=================================================")
# print("===                                           ===")
# print("===     SUKSES BUKANLAH KUNCI KEBAHAGIAAN     ===") 
# print("===                                           ===")
# print("===    KEBAHAGIAAN ADALAH KUNCI KESUKSESAN    ===")
# print("===                                           ===")
# print("=================================================")
# print("*************************************************")    