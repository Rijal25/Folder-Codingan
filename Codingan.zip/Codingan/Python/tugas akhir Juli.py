import random, string

def menu():
    print("="*41)
    print("******* SELAMAT DATANG DI RI BANK *******")
    print("="*41)
    print("[1] Buka Rekening\n[2] Setoran Tunai\n[3] Tarik Tunai\n[4] Transfer\n[5] Lihat Daftar Transfer\n[6] Keluar")
    inputan = input("Masukkan Menu Pilihan Anda: ")
    print("\n")
    if (inputan == "1"):
        buk_Rek()
    elif (inputan == "2"):
        set_Tun()
    elif (inputan == "3"):
        tar_Tun()
    elif (inputan == "4"):
        transfer()
    elif (inputan == "5"):
        daf_Trans()
    elif (inputan == "6"):
        keluar()
    else:
        print("Pilihan Anda Salah. Ulangi")
        back_menu()

def back_menu():
    print("\n")
    input = ("tekan enter untuk melanjutkan")
    menu()

    
def buk_Rek():
    print("***** BUKA REKENING *****")
    nama = str(input("Masukkan nama    : "))
    uang = int(input("Masukkan setoran : "))
    no_Rek =  "REK" + ''.join(random.choice(string.digits) for _ in range(3))
    print("Pembukaan rekening dengan nomor",no_Rek,"atas nama",nama,"telah berhasil")
    hasil = (nama, uang, no_Rek)

    nasabah = open("nasabah.txt", "a")
    nasabah.write(f"{hasil}\n")
    nasabah.close()
    menu()


def set_Tun():
    












































































