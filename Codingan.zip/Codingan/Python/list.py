# buah = ["apel", "anggur", "mangga", "jeruk"]

# print (buah[2])


# buah = ["jeruk", "apel", "mangga","duren"]

# buah[2] = "kelapa"
# print(buah)


# buah = ["jeruk", "apel", "mangga", "duren"]

# buah.append("manggis")
# print(buah)


# buah =["jeruk", "apel", "mangga", "duren"]

# buah.insert(2, "manggis")
# print(buah)


# hobi = []
# stop = False
# i = 0

# while(not stop):
#     hobi_baru = raw_input("Inputan hobi yang ke-{}: ".format(i))
#     hobi.append(hobi_baru)

#     i += 1

#     tanya = raw_input("Mau isi lagi? (y/t): ")
#     if(tanya == "t"):
#         stop = True

# print ("=") * 10
# print("Kamu memiliki {}".format(len(hobi)))
# for hb in hobi:
#     print("- {}".format(hb))


# cara menghapus item di list menggunakan del
# todo_list = [
#     "Belajar Python",
#     "Belajar HTML",
#     "Belajar JavaScript",
#     "Belajar Sulap",
#     "Belajar PHP"
# ]

# del todo_list[3]
# print(todo_list)

# # cara lainya untuk menghapus
# vokal = ["a", "i", "e", "o"]

# vokal.remove("i")

# print(vokal)


# warna = ["merah", "hijau", "kuning", "biru", "pink", "ungu"]

# print(warna [1:5])


#list muldi dimensi
# list_minuman = [
#     ["Kopi", "Susu", "Teh"],
#     ["Juz Apel", "Jus Melon", "Jus Jeruk"],
#     ["Es Kopi", "Es Campur", "Es Teler"]
# ]

# print(list_minuman[1][2])