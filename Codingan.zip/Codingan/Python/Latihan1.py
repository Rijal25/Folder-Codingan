# 1

# import turtle

# t = turtle.Turtle()
# s = turtle.Screen()
# s.bgcolor("black")
# color = ["red", "yellow", "white", "purple"]
# x, y = 1, 0
# t.speed(0)
# t.hideturtle()

# while True:
#     t.color(color[y])
#     t.pensize(x/75 + 1)
#     t.forward(x)
#     t.left(121)
#     x += 3
#     y += 1
#     if y == 4 :
#         y = 0
# turtle.done()

# 2

# import turtle

# t = turtle.Turtle()
# s = turtle.Screen()
# s.title("Membuat sebuah Kotak")
# s.bgcolor("light yellow")

# t.fillcolor("green")
# t.begin_fill()
# for i in range(4):
#     t.speed(1)
#     t.forward(100)
#     t.left(90)
# t.end_fill()
# turtle.done()
 
# 3

















