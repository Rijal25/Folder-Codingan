# # Menggunakan writelines
# hari = "Berikut nama-nama hari dalam 1 pekan \n"
# hari_list = ["~ Senin \n", "~ Selasa \n ", "~ Rabu \n", "~ Kamis \n", "~ Jum'at \n", "~ Sabtu \n", "~ Ahad \n"]

# f = open("hari.txt", "w")
# f.write(hari)
# f.writelines(hari_list)



# import os
# os.system('cls')


# profil = open("profil.txt", "r+")

# teks = profil.read()

# print(teks)

# nama = input("Nama: ")
# tempat = input("tmp: ")
# tanggal = input("tgl: ")
# umur = input("Umur: ")
# gender = input("gender: ")
# goldar = input("Golongan Darah: ")
# agama = input("agama: ")
# kwn = input("kwn: ")
# hp = input("hp: ")
# email = input("email: ")
# alamat = input("Alamat: ")

# teks = "\nNama: {}\ntmp: {}\ntgl: {}\nUmur: {}\ngender: {}\nGolongan Darah: {}\nagama: {}\nkwn: {}\nhp: {}\nemail: {}\nAlamat: {}\n---".format(nama, tempat, tanggal, umur, gender, goldar, agama, kwn, hp, email, alamat)

# profil.write(teks)

# profil.close()


# kata = open("kata.txt","r")

# print (kata.read())

# kata.close()