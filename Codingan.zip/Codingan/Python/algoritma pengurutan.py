# PENGURUTAN - SORTING

# #SELECTION SORT
# # membuat fungsi/function yang menerima parameter array
# def selection_sort(array):
#     # membuat for perulangan sebanyak isi/value dari array
#     for i in range(len(array)-1):
#         # membuat variabel index_awal dan mengisinya dengan i
#         index_awal = i
#         # membuat for perulangan dimana i + 1, dan loop sebanyak isi dari array
#         for j in range(i+1, len(array)):
#             # jika array[j] lebih kecil dari array[index_awal]
#             if array[j] < array[index_awal]:
#                 # maka index_awal = j
#                 index_awal= j
#         # mengubah value
#         array[i], array[index_awal] = array[index_awal], array[i]


# angka = [1, 4, 3, 9, 6, 5]
# selection_sort(angka)

# print(angka)


# # BUBBLE SORT

# angka = [9, 5, 8, 6, 7, 4, 3, 1, 2]

# def bubble_sort(array):
#     for i in range (len(array)-1):
#         for j in range (len(array)-1-i):
#             if array[j] > array[j+1]:
#                 array[j], array[j+1] = array[j+1], array[j]


# bubble_sort(angka)
# print(angka)


# # INSERTION SORT

# angka = [9, 5, 8, 6, 7, 4, 3, 1, 2]

# def insertion_sort(array):
#     for i in range(1, len(array)): 
#        value = array[i]
#        j = i - 1
#        while j >= 0 and array[j] > value:
#            array[j+1] = array[j]
#            j = j - 1
#     array[j+1] = value


# insertion_sort(angka)
# print(angka)


# MARGE SORT

# def merge(left, right, arr):
#     i, j, k = 0, 0, 0
#     while i < len(left) and j < len(right):
#         if left[i] < right[j]:
#             arr[k] = left[i]
#             i = i + 1
#         else:
#             arr[k] = right[j]
#             j = j + 1
#         k = k + 1
#     while i < len(left):
#         arr[k] = left[i]
#         k = k + 1
#         i = i + 1
#     while j < len(right):
#         arr[k] = right[j]
#         k = k + 1
#         j = j + 1


# def merge_sort(arr):
#     if len(arr) > 1:
#         mid = len(arr) // 2
#         leftarr = arr[:mid]
#         rightarr = arr[mid:]
#         merge_sort(leftarr)
#         merge_sort(rightarr)
#         merge(leftarr, rightarr, arr)

# angka = [7, 2, 1, 6, 8, 5, 3, 4]
# merge_sort(angka)
# print(angka)


#QUICK SORT

# angka = [7, 2, 1, 6, 8, 5, 3, 4]

# def quick_sort(arr):
#     quick_sort_rec(arr, 0, len(arr)-1)

# def quick_sort_rec(arr, start, end):
#     if start < end:
#         pivot_idx = partition(arr, start, end)
#         quick_sort_rec(arr, start, pivot_idx-1)
#         quick_sort_rec(arr, pivot_idx+1, end)

# def partition(arr, start, end):
#     pivot = arr[end]
#     i = start
#     for j in range(start, end):
#         if arr[j] <= pivot:
#             arr[i], arr[j] = arr[j], arr[i]
#             i = i + 1
#     arr[i], arr[end] = arr[end], arr[i]
#     return i


# quick_sort(angka)
# print(angka)


