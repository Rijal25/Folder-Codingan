# import csv

# with open('data.csv') as csv_baca:
#     csv_baca = csv.reader(csv_baca)
#     print(csv_baca)
#     for row in csv_baca:
#         print(row)


# Parsing CSV

# import csv
 
# data = []

# with open('data.csv') as csv_baca:
#     csv_baca = csv.reader(csv_baca)
#     for row in csv_baca:
#         data.append(row)

# print(data)


# Menggunakan method pop()

# import csv
 
# data = []

# with open('data.csv') as baca_csv:
#     csv_baca = csv.reader(baca_csv)
#     for row in csv_baca:
#         data.append(row)

# header = data.pop(0)

# print(header)
# print(data)

# baca_csv.close()



# import csv
 
# contacts = []

# with open('data.csv') as csv_file:
#     csv_baca = csv.reader(csv_file, delimiter=",")
#     for row in csv_baca:
#         contacts.append(row)

# header = contacts.pop(0)

# print(f'{header[0]} \t {header[1]} \t\t {header[2]}')
# print("-"*42)
# for data in contacts:
#     print(f'{data[0]} \t {data[1]} \t\t {data[2]}')

# csv_file.close()


# import csv
 
# data = []

# with open('data.csv') as csv_file:
#     csv_baca = csv.DictReader(csv_file)
#     for row in csv_baca:
#         data.append(row)

# print(data)

# csv_file.close()


# import csv



# with open('data.csv', mode='a') as csv_file:

#     writer = csv.writer(csv_file, quoting=csv.Quote_MINIMAL) 

#     writer.writerow(["6", "Mamat", "Jombang"])
#     writer.writerow(["7", "Ode", "Ambon"])

# print("Writing Done!")


# import csv

# with open('data.csv', mode='a') as baca_csv:

#     fieldnames = ['No', 'Nama', 'Alamat']

#     writer = csv.DictWriter(baca_csv, fieldnames=fieldnames)

#     writer.writerow({'No': '6', 'Nama': 'Mamat', 'Alamat': 'Jombang'})
#     writer.writerow({'No': '7', 'Nama': 'Ode', 'Alamat': 'Ambon'})

# print("Writing Done!")
