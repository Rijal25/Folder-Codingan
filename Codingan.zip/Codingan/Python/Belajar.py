# while ( 1 + 2 == 3 ):
#     print('Halo dunia!')


# for i in range(6):
#     print(i)

# i = 0

# while i <= 5:
#      print(i)
#      i = i + 1


# listKota = ['Jakarta', 'Surabaya', 'Depok', 'Bekasi', 'Solo', 'jogjakarta', 'Semarang', 'Makassar']

# i = 0
# while i < len(listKota):
#     print(listKota[i])
#     i += 1


# a = int(input('Masukkan bilangan ganjil lebih dari 50:'))
# while a % 2 != 1 or a <= 50:
#     a = int(input('Salah, masukkan lagi: '))

# print('Benar')











