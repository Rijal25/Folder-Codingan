# import turtle
# import colorsys
# t = turtle.Turtle()
# turtle.Screen().bgcolor("black")
# t.speed(0)
# n = 36
# h = 0
# for i in range(160):
#     c = colorsys.hsv_to_rgb(h,1,0.9)
#     h+=1/n
#     t.color(c)
#     t.left(145)
#     for i in range(5):
#         t.forward(300)
#         t.left(150)
# turtle.done()


# 2 donut
# from turtle import *

# bgcolor('black')
# speed(0)
# hideturtle()

# for i in range(120):
#     color('#FF9933')
#     circle(90)
#     color('#FFFFFF')
#     circle(60)
#     color('blue')
#     circle(30)
#     right(3)
#     forward(3)
# done()


#3 windows

# import turtle
# t = turtle.Turtle()
# t.speed(3)
# turtle.Screen().bgcolor("black")
# t.penup()
# t.goto(-50,60)
# t.pendown()
# t.color("#00adef")
# t.begin_fill()
# t.goto(100,100)
# t.goto(100,-100)
# t.goto(-50,-60)
# t.goto(-50,60)
# t.end_fill()
# t.color("black")
# t.goto(15,100)
# t.color("black")
# t.width(10)
# t.goto(15,-100)
# t.penup()
# t.goto(100,0)
# t.pendown()
# t.goto(-100,0)
# turtle.done()


#4 triangle

# import turtle
# import colorsys

# t = turtle.Turtle()
# t.screen.bgcolor("black")

# t.penup()
# t.goto(-200,-100)
# t.pendown()
# t.speed(10)

# a=400
# h=0
# n=100

# def triangle():
#     global a,n,h
#     for i in range(40):
#         c = colorsys.hsv_to_rgb(h,1,0.6)
#         h=h+(1/n)
#         t.color(c)
#         t.forward(a)
#         t.left(120)
#         a=a-10

# triangle()
# triangle()

# t.hideturtle()
# turtle.done()


#5 I love you

# import turtle
# t = turtle.Turtle()
# turtle.Screen().bgcolor("black")

# t.penup()
# t.goto(-230,175)
# t.pendown()

# t.pencolor("white")
# t.pensize(15)
# t.forward(100)
# t.backward(50)
# t.right(90)
# t.forward(170)
# t.right(90)
# t.forward(50)
# t.backward(100)

# t.penup()
# t.goto(0,0)
# t.pendown()

# t.color("red")
# t.begin_fill()
# t.right(130)
# t.forward(133)
# t.circle(50,200)
# t.right(140)
# t.circle(50,200)
# t.forward(133)
# t.end_fill()

# t.penup()
# t.goto(140,175)
# t.pendown()

# t.pencolor("white")
# t.right(40)
# t.forward(120)
# t.circle(60,180)
# t.forward(120)

# t.penup()
# t.goto(-150,-150)
# t.pendown()
# t.write("Indira Candra",font=("Arial",40,"bold"))

# t.hideturtle()
# turtle.done()