# angka = 5

# for i in range(3):
#     print('No : ', i, ' berisi:', angka)

# angka = 1

# for i in range(10):
#     print(angka)

# membuat array mobil
# index 0 = Honda Jazz
# index 1 = Avanza
# index 2 = Kijang

# mobil = ['Honda Jazz', 'Avanza', 'Kijang']
# print(mobil[1])
# print(mobil)

# mobil = ['Honda Jazz', 'Avanza', 'Kijang']

# for i in mobil:
#     print(mobil[0])

# mobil = ['Honda Jazz', 'Avanza', 'Kijang']

# for indeks in mobil:
#     print(indeks)


# mobil = ['Honda Jazz', 'Avanza', 'Kijang']

# for nama_mobil in mobil:
#     print(nama_mobil)



# Membuat array buah-buahan
# Jumlah Index 6
# Looping menggunakan for

# buah = ['mangga', 'apel', 'anggur', 'jeruk', 'pisang', 'nanas', 'ceri']

# # Melakukan perulangan for
# for buah_buahan in buah:
#     # Mencetak buah-buahan
#     print("Nama buah : ", buah_buahan)






# Membuat Program Biodata

# # Membuat variabel nama_saya yang menerima inputan
# nama_lengkap = input("Masukkan Nama Lengkap : ")

# # Membuat variabel asal_daerah yang menerima inputan
# asal_daerah = input("Masukkan Asal Daerah : ")

# # Membuat variabel array biodata untuk mengumpulkan hasil inputan
# biodata = [ nama_lengkap, asal_daerah ]

# no = 0
# for isi_biodata in biodata : 
#     print(biodata[no])
#     no = no + 1

# # Manual
# print(biodata[0])
# print(biodata[1])


# Membuat array siswa
# siswa = []

# # Membuat perulangan for
# for i in range(3):

#     # Mengecek nilai indeks
#     print("ini adalah indeks ke-",i)

#     # Menerima inputan nama
#     nama_siswa = input("Masukkan nama siswa : ")

#     # Memasukkan hasil inputan nama ke array siswa
#     siswa.append(nama_siswa)

# print(**)

# # Membuat perulangan untuk mencetak data dari array siswa  
# for k in siswa:

#     # Mencetak array siswa
#     print("Nama Siswa : ", k)








