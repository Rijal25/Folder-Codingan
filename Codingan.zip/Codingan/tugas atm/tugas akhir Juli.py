import random, string
import os
os.system('cls')


print("="*41)
print("******* SELAMAT DATANG DI RI BANK *******")
print("="*41)


def menu():
    print("\nMENU :")
    print("[1] Buka Rekening\n[2] Setoran Tunai\n[3] Tarik Tunai\n[4] Transfer\n[5] Lihat Daftar Transfer\n[6] Keluar")
    inputan = input("Masukkan Menu Pilihan Anda: ")
    if (inputan == "1"):
        buk_Rek()
    elif (inputan == "2"):
        set_Tun()
    elif (inputan == "3"):
        tar_Tun()
    elif (inputan == "4"):
        transfer()
    elif (inputan == "5"):
        daf_Trans()
    elif (inputan == "6"):
        keluar()
    else:
        print("Pilihan Anda Salah. Ulangi")
        back_menu()

def back_menu():
    print("\n")
    input = ("tekan enter untuk melanjutkan")
    menu()

    
def buk_Rek():
    print("\n***** BUKA REKENING *****")
    nama = input("Masukkan nama: ")
    setoran_awal = int(input("Masukkan setoran awal: "))
    no_Rek =  "REK" + ''.join(random.choice(string.digits) for _ in range(3))
    saldo = setoran_awal
    print("Pembukaan rekening dengan nomor",no_Rek,"atas nama",nama,"telah berhasil")
    hasil = no_Rek,nama,setoran_awal

    nasabah = open("nasabah.txt", "a")
    nasabah.write(f"{hasil}\n")
    nasabah.close()
    menu()


def set_Tun():
    print("\n***** SETORAN TUNAI *****")
    noRek = input("Masukkan nomor rekening: ")
    with open("nasabah.txt", "r") as nasabah:
        if noRek in nasabah.read():
            print("berhasil")
        else:
            print("Nomor rekening tidak terdaftar")
            set_Tun()
    setor = int(input("Masukkan nominal yang akan disetor: "))
    

    








def tar_Tun():
    print("\n***** TARIK TUNAI *****")
    noRek = input("Masukkan nomor rekening: ")
    n0minal = int(input("Masukkan nominal yang akan ditarik: "))













def transfer():
    print("\n***** TRANSFER *****")
    sumber = input("Masukkan nomor rekening sumber: ")
    tujuan = input("Masukkan nomor rekening tujuan: ")
    nom1nal = int(input("Masukkan "))












def daf_Trans():
    print("\n***** LIHAT DATA TRANSFER *****")
    rek = input("Masukkan nomor rekening sumber transfer:  ")
    with open("transfer.txt","") as transfer:
        if rek in transfer():
            print(transfer)
        
        else:
            print("Tidak ada data yang ditampilkan")















def keluar():
    print("Terima kasih atas kunjungan Anda...")
    

    
menu()




















































































